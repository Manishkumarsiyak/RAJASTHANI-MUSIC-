package com.example.audio

import android.content.Context
import android.media.MediaPlayer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

enum class AudioTrackType {
    ORIGINAL,
    MODIFIED
}

data class PlayerState(
    val isPlaying: Boolean = false,
    val currentTrack: AudioTrackType = AudioTrackType.MODIFIED,
    val currentPositionMs: Int = 0,
    val durationMs: Int = 0,
    val isReady: Boolean = false
)

class AudioPlayerManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val TAG = "AudioPlayerManager"
    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null

    private var originalFile: File? = null
    private var modifiedFile: File? = null

    private val _playerState = MutableStateFlow(PlayerState())
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    fun setFiles(original: File?, modified: File?, defaultTrack: AudioTrackType = AudioTrackType.MODIFIED) {
        originalFile = original
        modifiedFile = modified
        switchTrack(defaultTrack, autoPlay = false)
    }

    fun switchTrack(trackType: AudioTrackType, autoPlay: Boolean = false) {
        val targetFile = if (trackType == AudioTrackType.MODIFIED) modifiedFile else originalFile
        if (targetFile == null || !targetFile.exists()) {
            Log.w(TAG, "Target file for $trackType does not exist")
            return
        }

        val previousPos = mediaPlayer?.currentPosition ?: 0
        val wasPlaying = mediaPlayer?.isPlaying ?: false

        releasePlayer()

        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(targetFile.absolutePath)
                prepare()
                setOnCompletionListener {
                    _playerState.value = _playerState.value.copy(isPlaying = false, currentPositionMs = 0)
                    stopProgressTracking()
                }
            }

            val duration = mediaPlayer?.duration ?: 0
            val seekTarget = if (previousPos < duration) previousPos else 0
            if (seekTarget > 0) {
                mediaPlayer?.seekTo(seekTarget)
            }

            _playerState.value = PlayerState(
                isPlaying = false,
                currentTrack = trackType,
                currentPositionMs = seekTarget,
                durationMs = duration,
                isReady = true
            )

            if (autoPlay || wasPlaying) {
                play()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize media player for $trackType", e)
        }
    }

    fun togglePlayPause() {
        if (mediaPlayer == null) return
        if (mediaPlayer?.isPlaying == true) {
            pause()
        } else {
            play()
        }
    }

    fun play() {
        try {
            mediaPlayer?.start()
            _playerState.value = _playerState.value.copy(isPlaying = true)
            startProgressTracking()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start playback", e)
        }
    }

    fun pause() {
        try {
            mediaPlayer?.pause()
            _playerState.value = _playerState.value.copy(isPlaying = false)
            stopProgressTracking()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to pause playback", e)
        }
    }

    fun seekTo(positionMs: Int) {
        try {
            mediaPlayer?.seekTo(positionMs)
            _playerState.value = _playerState.value.copy(currentPositionMs = positionMs)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to seek to $positionMs", e)
        }
    }

    private fun startProgressTracking() {
        stopProgressTracking()
        progressJob = scope.launch(Dispatchers.Main) {
            while (isActive && mediaPlayer?.isPlaying == true) {
                val current = mediaPlayer?.currentPosition ?: 0
                val total = mediaPlayer?.duration ?: 0
                _playerState.value = _playerState.value.copy(
                    currentPositionMs = current,
                    durationMs = total,
                    isPlaying = true
                )
                delay(200)
            }
        }
    }

    private fun stopProgressTracking() {
        progressJob?.cancel()
        progressJob = null
    }

    fun release() {
        stopProgressTracking()
        releasePlayer()
        _playerState.value = PlayerState()
    }

    private fun releasePlayer() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing player", e)
        } finally {
            mediaPlayer = null
        }
    }
}
