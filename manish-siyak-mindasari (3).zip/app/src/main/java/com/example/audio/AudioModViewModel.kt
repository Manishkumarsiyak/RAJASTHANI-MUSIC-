package com.example.audio

import android.app.Application
import android.net.Uri
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

data class SmartPreset(
    val id: String,
    val titleHindi: String,
    val titleEnglish: String,
    val description: String,
    val badge: String,
    val config: AdvancedDspConfig
)

val ADVANCED_PRESETS = listOf(
    SmartPreset(
        id = "natural_shield",
        titleHindi = "नेचुरल शील्ड",
        titleEnglish = "Natural Shield",
        description = "न्यूनतम बदलाव, 100% ओरिजिनल आवाज़ और मिठास। 5ms स्टीरियो फेज़ शिफ्ट + स्थिर 1.012x माइक्रो-पिच।",
        badge = "100% Original Tone",
        config = AdvancedDspConfig(
            presetId = "natural_shield",
            pitchMultiplier = 1.012f,
            tempoMultiplier = 1.00f,
            channelDelayMs = 5,
            subBassBoostDb = 0.5f,
            trebleAirBoostDb = 0.8f,
            midVocalCutDb = 0.0f,
            enableMicroDrift = true,
            enableVocalExciter = true,
            enableAmbientLayer = false,
            enableLoudnorm = true,
            enableVideoVisualShield = true,
            stripMetadata = true,
            audioBitrate = "320k"
        )
    ),
    SmartPreset(
        id = "deep_wave",
        titleHindi = "डीप वेव मॉड",
        titleEnglish = "Deep Wave Mod",
        description = "फेज़ शिफ्ट (6ms) + स्थिर 1.015x माइक्रो-पिच + सॉफ्ट हाई-शेल्फ EQ + -60dB इनऑडिबल लेयर + लाउडनॉर्म।",
        badge = "Maximum Protection",
        config = AdvancedDspConfig(
            presetId = "deep_wave",
            pitchMultiplier = 1.015f,
            tempoMultiplier = 1.00f,
            channelDelayMs = 6,
            subBassBoostDb = 1.0f,
            trebleAirBoostDb = 1.2f,
            midVocalCutDb = 0.0f,
            enableMicroDrift = true,
            enableVocalExciter = true,
            enableAmbientLayer = true,
            enableLoudnorm = true,
            enableVideoVisualShield = true,
            stripMetadata = true,
            audioBitrate = "320k"
        )
    ),
    SmartPreset(
        id = "bpm_shift",
        titleHindi = "बीपीएम शिफ्ट",
        titleEnglish = "BPM Shift",
        description = "सूक्ष्म टेम्पो 1.015x + पिच बैलेंस + वोकल एयर शेल्फ + 7ms स्टीरियो डिले + लाउडनेस नॉर्मलाइज़ेशन।",
        badge = "Rhythm Shift",
        config = AdvancedDspConfig(
            presetId = "bpm_shift",
            pitchMultiplier = 1.015f,
            tempoMultiplier = 1.015f,
            channelDelayMs = 7,
            subBassBoostDb = 1.0f,
            trebleAirBoostDb = 1.0f,
            midVocalCutDb = 0.0f,
            enableMicroDrift = true,
            enableVocalExciter = true,
            enableAmbientLayer = true,
            enableLoudnorm = true,
            enableVideoVisualShield = true,
            stripMetadata = true,
            audioBitrate = "320k"
        )
    )
)

class AudioModViewModel(application: Application) : AndroidViewModel(application) {

    private val _selectedAudio = MutableStateFlow<AudioFileInfo?>(null)
    val selectedAudio: StateFlow<AudioFileInfo?> = _selectedAudio.asStateFlow()

    private val _processingState = MutableStateFlow<ProcessingState>(ProcessingState.Idle)
    val processingState: StateFlow<ProcessingState> = _processingState.asStateFlow()

    private val _selectedPresetIndex = MutableStateFlow(1) // Default to "Deep Wave Mod" (Mode 2)
    val selectedPresetIndex: StateFlow<Int> = _selectedPresetIndex.asStateFlow()

    // Waveform comparison data
    private val _waveformDiffData = MutableStateFlow(WaveformDiffData(emptyList(), emptyList(), 0f, false))
    val waveformDiffData: StateFlow<WaveformDiffData> = _waveformDiffData.asStateFlow()

    // Custom Mode Sliders & Flags
    private val _customDelayMs = MutableStateFlow(6)
    val customDelayMs: StateFlow<Int> = _customDelayMs.asStateFlow()

    private val _customPitch = MutableStateFlow(1.015f)
    val customPitch: StateFlow<Float> = _customPitch.asStateFlow()

    private val _customBassBoost = MutableStateFlow(1.0f)
    val customBassBoost: StateFlow<Float> = _customBassBoost.asStateFlow()

    private val _customTrebleAir = MutableStateFlow(1.2f)
    val customTrebleAir: StateFlow<Float> = _customTrebleAir.asStateFlow()

    private val _enableMicroDrift = MutableStateFlow(true)
    val enableMicroDrift: StateFlow<Boolean> = _enableMicroDrift.asStateFlow()

    private val _enableVocalExciter = MutableStateFlow(true)
    val enableVocalExciter: StateFlow<Boolean> = _enableVocalExciter.asStateFlow()

    private val _customAmbientLayer = MutableStateFlow(true)
    val customAmbientLayer: StateFlow<Boolean> = _customAmbientLayer.asStateFlow()

    private val _customLoudnorm = MutableStateFlow(true)
    val customLoudnorm: StateFlow<Boolean> = _customLoudnorm.asStateFlow()

    private val _enableVideoVisualShield = MutableStateFlow(true)
    val enableVideoVisualShield: StateFlow<Boolean> = _enableVideoVisualShield.asStateFlow()

    private val _stripMetadata = MutableStateFlow(true)
    val stripMetadata: StateFlow<Boolean> = _stripMetadata.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    val playerManager = AudioPlayerManager(application.applicationContext, viewModelScope)
    val playerState: StateFlow<PlayerState> = playerManager.playerState

    fun onMediaSelected(uri: Uri) {
        viewModelScope.launch {
            _processingState.value = ProcessingState.Idle
            playerManager.release()
            _waveformDiffData.value = WaveformDiffData(emptyList(), emptyList(), 0f, false)
            val info = StorageHelper.copyUriToCache(getApplication(), uri)
            _selectedAudio.value = info
            if (info != null) {
                val mediaLabel = if (info.isVideo) "Shorts Video" else "Audio"
                val app = getApplication<Application>()
                _statusMessage.value = app.getString(R.string.status_selected_prefix, mediaLabel, info.name)
                // Pre-compute original waveform amplitudes
                val originalAmps = WaveformSpectrogramHelper.extractAmplitudes(info.localFile)
                _waveformDiffData.value = WaveformDiffData(
                    originalAmplitudes = originalAmps,
                    modifiedAmplitudes = emptyList(),
                    variancePercentage = 0f,
                    isReady = false
                )
            } else {
                val app = getApplication<Application>()
                _statusMessage.value = app.getString(R.string.status_load_failed)
            }
        }
    }

    fun setPresetIndex(index: Int) {
        _selectedPresetIndex.value = index
    }

    fun setCustomDelayMs(ms: Int) {
        _customDelayMs.value = ms
    }

    fun setCustomPitch(pitch: Float) {
        _customPitch.value = pitch
    }

    fun setCustomBassBoost(boost: Float) {
        _customBassBoost.value = boost
    }

    fun setCustomTrebleAir(air: Float) {
        _customTrebleAir.value = air
    }

    fun setEnableMicroDrift(enable: Boolean) {
        _enableMicroDrift.value = enable
    }

    fun setEnableVocalExciter(enable: Boolean) {
        _enableVocalExciter.value = enable
    }

    fun setCustomAmbientLayer(enable: Boolean) {
        _customAmbientLayer.value = enable
    }

    fun setCustomLoudnorm(enable: Boolean) {
        _customLoudnorm.value = enable
    }

    fun setEnableVideoVisualShield(enable: Boolean) {
        _enableVideoVisualShield.value = enable
    }

    fun setStripMetadata(strip: Boolean) {
        _stripMetadata.value = strip
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun startProcessing() {
        val mediaInfo = _selectedAudio.value ?: return

        val config = if (_selectedPresetIndex.value < ADVANCED_PRESETS.size) {
            val preset = ADVANCED_PRESETS[_selectedPresetIndex.value]
            preset.config.copy(
                stripMetadata = _stripMetadata.value,
                enableVideoVisualShield = _enableVideoVisualShield.value
            )
        } else {
            AdvancedDspConfig(
                presetId = "custom_pro",
                pitchMultiplier = _customPitch.value,
                tempoMultiplier = 1.00f,
                channelDelayMs = _customDelayMs.value,
                subBassBoostDb = _customBassBoost.value,
                trebleAirBoostDb = _customTrebleAir.value,
                midVocalCutDb = 0.0f,
                enableMicroDrift = _enableMicroDrift.value,
                enableVocalExciter = _enableVocalExciter.value,
                enableAmbientLayer = _customAmbientLayer.value,
                enableLoudnorm = _customLoudnorm.value,
                enableVideoVisualShield = _enableVideoVisualShield.value,
                stripMetadata = _stripMetadata.value,
                audioBitrate = "320k"
            )
        }

        val app = getApplication<Application>()
        _processingState.value = ProcessingState.Processing(0, app.getString(R.string.processing_starting))
        playerManager.release()

        viewModelScope.launch {
            val result = if (mediaInfo.isVideo) {
                AudioProcessor.processVideoForShorts(
                    context = getApplication(),
                    inputFile = mediaInfo.localFile,
                    totalDurationMs = mediaInfo.durationMs,
                    config = config,
                    onProgress = { percent, stage, _ ->
                        _processingState.value = ProcessingState.Processing(
                            progressPercentage = percent,
                            stageMessage = stage
                        )
                    }
                )
            } else {
                AudioProcessor.processAudio(
                    context = getApplication(),
                    inputFile = mediaInfo.localFile,
                    totalDurationMs = mediaInfo.durationMs,
                    config = config,
                    onProgress = { percent, stage, _ ->
                        _processingState.value = ProcessingState.Processing(
                            progressPercentage = percent,
                            stageMessage = stage
                        )
                    }
                )
            }
            _processingState.value = result

            if (result is ProcessingState.Success) {
                // If it produced an audio track, load it into A/B player
                if (result.outputFile.exists() && result.outputFile.extension == "mp3") {
                    playerManager.setFiles(
                        original = mediaInfo.localFile,
                        modified = result.outputFile,
                        defaultTrack = AudioTrackType.MODIFIED
                    )
                }

                // Compute dual waveform amplitudes and spectrogram diff
                val origAmps = _waveformDiffData.value.originalAmplitudes.ifEmpty {
                    WaveformSpectrogramHelper.extractAmplitudes(mediaInfo.localFile)
                }
                val modAmps = WaveformSpectrogramHelper.extractAmplitudes(result.outputFile)
                _waveformDiffData.value = WaveformSpectrogramHelper.computeDiff(origAmps, modAmps)

                _statusMessage.value = if (result.isVideo) {
                    app.getString(R.string.status_video_ready)
                } else {
                    app.getString(R.string.status_audio_ready)
                }
            } else if (result is ProcessingState.Error) {
                _statusMessage.value = app.getString(R.string.status_process_failed, result.message)
            }
        }
    }

    fun exportAudio(saveToMusic: Boolean = false) {
        val currentState = _processingState.value
        val mediaInfo = _selectedAudio.value
        if (currentState is ProcessingState.Success && mediaInfo != null) {
            viewModelScope.launch {
                val targetDir = if (saveToMusic) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_DOWNLOADS
                val saveResult = StorageHelper.saveAudioExport(
                    context = getApplication(),
                    sourceFile = currentState.outputFile,
                    originalName = mediaInfo.name,
                    targetDirectory = targetDir
                )
                val app = getApplication<Application>()
                saveResult.onSuccess { msg ->
                    _statusMessage.value = msg
                }.onFailure { err ->
                    _statusMessage.value = app.getString(R.string.status_save_failed, err.message ?: "")
                }
            }
        }
    }

    fun exportVideo() {
        val currentState = _processingState.value
        val mediaInfo = _selectedAudio.value
        if (currentState is ProcessingState.Success && currentState.outputVideoFile != null && mediaInfo != null) {
            viewModelScope.launch {
                val saveResult = StorageHelper.saveVideoExport(
                    context = getApplication(),
                    sourceFile = currentState.outputVideoFile,
                    originalName = mediaInfo.name
                )
                val app = getApplication<Application>()
                saveResult.onSuccess { msg ->
                    _statusMessage.value = msg
                }.onFailure { err ->
                    _statusMessage.value = app.getString(R.string.status_video_save_failed, err.message ?: "")
                }
            }
        }
    }

    fun shareMedia(isVideo: Boolean = false) {
        val currentState = _processingState.value
        if (currentState is ProcessingState.Success) {
            val fileToShare = if (isVideo && currentState.outputVideoFile != null) {
                currentState.outputVideoFile
            } else {
                currentState.outputFile
            }
            StorageHelper.shareMedia(
                context = getApplication(),
                file = fileToShare,
                isVideo = isVideo,
                title = if (isVideo) "Share YouTube Short Video" else "Share Audio"
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.release()
    }
}
